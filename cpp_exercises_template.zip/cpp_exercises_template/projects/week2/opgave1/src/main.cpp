// Week 2 - Opgave 1: Klasser
#include <iostream>
#include "person.h"  // Fra shared/include/

int main() {
    std::cout << "=== Week 2, Opgave 1 ===" << std::endl;

    Person p{"Alice", 25};
    std::cout << p.to_string() << std::endl;

    return 0;
}
