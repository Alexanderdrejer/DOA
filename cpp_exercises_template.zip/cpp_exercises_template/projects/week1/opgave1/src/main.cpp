// Week 1 - Opgave 1: Hello World
#include <iostream>

int main() {
    std::cout << "=== Week 1, Opgave 1 ===" << std::endl;
    std::cout << "Hello World!" << std::endl;

    return 0;
}
