// Week 1 - Opgave 2: Variabler og input
#include <iostream>
#include <string>

int main() {
    std::cout << "=== Week 1, Opgave 2 ===" << std::endl;

    std::string name;
    std::cout << "Hvad hedder du? ";
    std::getline(std::cin, name);

    std::cout << "Hej " << name << "!" << std::endl;

    return 0;
}
